
Abena's World of Health and Habits
My name is Abena.This website focuses on my interests. I would like users to be introduced to the concepts of nutrition, physical, and mental fitness that I use daily.
I have contact information if the users would like to consult with me about changing their weight, their mindset, or their exercise routine. Html, Boostrap, and css was used. I would like to change the colors of the website, the navigation bar of the website, and validate the form. I also change the size of the media.
