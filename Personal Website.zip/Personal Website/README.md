# Helloworld-
a starter repository
I am a student in the Web development bootcamp. I enjoy coding, cooking, joggin, and cycling. I want to use these skills to recieve a better job. I signed up for GitHub to keep record of my projects.
